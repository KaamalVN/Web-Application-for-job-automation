import React from "react"
import HeadLinking from "./Components/HeadLinking"
//import HeadNavBar from "./Components/HeadNavBar"
//import LoginPage from "./Components/LoginPage"
//import HeadWorkStatus from "./Components/HeadWorkStatus"
//import HeadReportGeneration from "./Components/HeadReportGeneration"
//import HeadRequest from "./Components/HeadRequest"
//import HeadAssign from "./Components/HeadAssign"
export default function App() {
  return <HeadLinking />  
}
